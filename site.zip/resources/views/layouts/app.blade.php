<!DOCTYPE html>
<html>
<head>
    <title>{{ $title ?? 'WeebsWebRO' }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        :root {
            color-scheme: light dark;
        }
        body {
            background-color: light-dark(#f2f2f5, #1c1b22);
            color: light-dark(#1c1b22, #f2f2f5);
            padding: 20px;
        }

        a, .btn {
            margin-right: 5px;
        }

        hr {
            border-color: light-dark(#ccc, #444);
        }

        .form-control {
            background-color: light-dark(#ffffff, #2b2a33);
            color: light-dark(#1c1b22, #f2f2f5);
            border: 1px solid light-dark(#ccc, #555);
        }

        .form-control:focus {
            background-color: light-dark(#ffffff, #2b2a33);
            color: inherit;
            border-color: light-dark(#888, #777);
            box-shadow: none;
        }

        .btn-primary {
            background-color: #3a7afe;
            border-color: #3a7afe;
        }

        .btn-danger {
            background-color: #d9534f;
            border-color: #d9534f;
        }

        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
    </style>
</head>
<body>
    @auth
        <p>Logged in as {{ auth()->user()->username }}</p>

        <form action="{{ url('logout') }}" method="POST" style="display:inline">
            @csrf
            <button class="btn btn-sm btn-danger" type="submit">Logout</button>
        </form>

        @if (!request()->is('change-password'))
            <a class="btn btn-sm btn-primary" href="{{ url('change-password') }}">Change Password</a>
        @endif

        @if (!request()->is('home'))
            <a class="btn btn-sm btn-secondary" href="{{ url('home') }}">Home</a>
        @endif
    @endauth

    @guest
        @if (!request()->is('login'))
            <a class="btn btn-sm btn-primary" href="{{ url('login') }}">Login</a>
        @endif
        @if (!request()->is('register'))
            <a class="btn btn-sm btn-success" href="{{ url('register') }}">Register</a>
        @endif
                @if (!request()->is('home'))
            <a class="btn btn-sm btn-secondary" href="{{ url('home') }}">Home</a>
        @endif
    @endguest

    <hr>

    @yield('content')

</body>
</html>
