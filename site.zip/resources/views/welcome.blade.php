@extends('layouts.app')

@section('content')
<h1 class="mb-4">Welcome to WeebsWebRO!</h1>

@auth
    <h3>You are logged in! Need assistance getting the game set up? Check Discord!</p>
@else
    <h3>Please login or register.</p>
@endauth
@endsection
