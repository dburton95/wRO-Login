@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h1 class="mb-4">Change Password</h1>

    @if (session('status'))
        <div style="color: green;">{{ session('status') }}</div>
    @endif

    @if ($errors->any())
        <div style="color: red;">
            <ul>
                @foreach ($errors->all() as $e)
                    <li>{{ $e }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ url('change-password') }}">
        @csrf

        <div class="mb-3">
            <label class="form-label">New Password</label><br>
            <input class="form-control" type="password" name="password" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Confirm New Password</label><br>
            <input class="form-control" type="password" name="password_confirmation" required>
        </div>

        <button class="btn btn-primary" type="submit">Update Password</button>
    </form>
</div>
@endsection
