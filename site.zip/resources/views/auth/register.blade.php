@extends('layouts.app')

@section('content')
<div class="container mt-5">
<h1 class="mb-4">Register</h1>

@if ($errors->any())
    <div style="color: red;">
        <ul>
            @foreach ($errors->all() as $e)
                <li>{{ $e }}</li>
            @endforeach
        </ul>
    </div>
@endif

    <form method="POST" action="{{ url('register') }}">
        @csrf

        <div class="mb-3">
            <label class="form-label">Username</label><br>
            <input class="form-control" type="text" name="username" value="{{ old('username') }}" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label><br>
            <input class="form-control" type="password" name="password" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Confirm Password</label><br>
            <input class="form-control" type="password" name="password_confirmation" required>
        </div>

        <button class="btn btn-primary" type="submit">Register</button>
    </form>
</div>
@endsection
