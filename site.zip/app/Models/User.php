<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    protected $table = "login";
    protected $primaryKey = "account_id";
    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'userid',
        'user_pass',
        'sex'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'user_pass',
    ];

    protected $attributes = [
        'email' => '',
        'group_id' => 0,
        'state' => 0,
        'unban_time' => 0,
        'expiration_time' => 0,
        'logincount' => 0,
        'last_ip' => '',
        'character_slots' => 0,
        'pincode' => '0',
        'pincode_change' => 0,
        'vip_time' => 0,
        'old_group' => 0,
        'web_auth_token_enabled' => 0
    ];
}
