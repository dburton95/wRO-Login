<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function show()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'username'=> 'required|string|min:4|unique:users',
            'password'=> [
                'required',
                'string',
                'confirmed',
                'min:8',
                'regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z\d\s]).*$/'
            ],
        ], [
            'password.regex' => 'The password must contain at least one uppercase letter, one number, and one symbol.'
        ]);

        $num = rand(0,69);

        $user = User::create([
            'userid'=> $data['username'],
            'user_pass' => $data['password'],
            'sex' => $num % 2 == 0 ? 'F' : 'M'
        ]);

        Auth::login($user);

        return redirect()->route('home');
    }
}
