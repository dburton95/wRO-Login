<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class PasswordController extends Controller
{
    public function show()
    {
        return view('auth.change-password');
    }

    public function update(Request $request)
    {
        $request->validate([
            'password'=> [
                'required',
                'string',
                'confirmed',
                'min:8',
                'regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z\d\s]).*$/'
            ],
        ], [
            'password.regex' => 'The password must contain at least one uppercase letter, one number, and one symbol.'
        ]);

        $user = $request->user();
        $user->password = $request->password;
        $user->save();

        return redirect()->route('home')->with('status', 'Password updated.');
    }
}
