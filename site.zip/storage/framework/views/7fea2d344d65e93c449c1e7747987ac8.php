<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Welcome to WeebsWebRO!</h1>

<?php if(auth()->guard()->check()): ?>
    <h3>You are logged in! Need assistance getting the game set up? Check Discord!</p>
<?php else: ?>
    <h3>Please login or register.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Laravel\account-management\resources\views/welcome.blade.php ENDPATH**/ ?>