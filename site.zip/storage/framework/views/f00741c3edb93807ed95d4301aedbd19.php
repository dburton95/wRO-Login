

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
<h1 class="mb-4">Register</h1>

<?php if($errors->any()): ?>
    <div style="color: red;">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

    <form method="POST" action="/register">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label class="form-label">Username</label><br>
            <input class="form-control" type="text" name="username" value="<?php echo e(old('username')); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Password</label><br>
            <input class="form-control" type="password" name="password" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Confirm Password</label><br>
            <input class="form-control" type="password" name="password_confirmation" required>
        </div>

        <button class="btn btn-primary" type="submit">Register</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Laravel\account-management\resources\views/auth/register.blade.php ENDPATH**/ ?>