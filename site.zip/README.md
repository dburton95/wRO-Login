# RO Accounts — Simple Laravel Authentication App

This is a lightweight Laravel application providing:

- Username + password registration
- Login and logout
- Change password functionality
- Blade-only frontend (no Vue, React, or build tools)
- MySQL database support
- Fully self-contained — no Node.js or NPM required

The UI uses only Blade templates and CDN-based CSS, keeping the project minimal and easy to maintain.

## 1. Requirements

To run this application, the server must have:

- PHP 8.2+
- Composer
- MySQL
- Web server (Apache or NGINX)
- PHP extensions:
  - OpenSSL
  - PDO and PDO MySQL
  - Mbstring
  - Tokenizer
  - XML
  - Ctype
  - JSON
  - Fileinfo

```bash
sudo apt update
sudo apt install \
    php \
    php-cli \
    php-fpm \
    php-mbstring \
    php-xml \
    php-zip \
    php-curl \
    php-mysql \
    php-tokenizer \
    php-json \
    php-ctype \
    php-fileinfo \
    php-openssl
```

Node.js and NPM are **not** required.

## 2. Local Installation

### Step 1 — Clone the repository

```bash
git clone <repo-url>
cd ro-accounts
```

### Step 2 — Install dependencies

```bash
composer install
```

### Step 3 — Create your environment file

```bash
cp .env.example .env
```

Then edit `.env`:

```env
APP_NAME="RO Accounts"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=ro_accounts
DB_USERNAME=root
DB_PASSWORD=
```

### Step 4 — Generate the app key

```bash
php artisan key:generate
```

### Step 5 — Run database migrations

```bash
php artisan migrate
```

### Step 6 — Serve the project

```bash
php artisan serve
```

The app will run at:

```
http://localhost:8000
```

## 3. Production Deployment

These are the steps for deploying on a server

### Step 1 — Upload or pull the project

Either upload the project or run:

```bash
git clone <repo-url>
```

### Step 2 — Install production dependencies

```bash
composer install --no-dev --optimize-autoloader
```

### Step 3 — Create and configure `.env`

```bash
cp .env.example .env
```

Then configure for production:

```env
APP_ENV=production
APP_DEBUG=false
APP_URL="https://example.com/wro"

DB_CONNECTION=mysql
DB_HOST=localhost
DB_DATABASE=ro_accounts
DB_USERNAME=YOUR_DB_USER
DB_PASSWORD=YOUR_DB_PASSWORD

SESSION_SECURE_COOKIE=true
```

### Step 4 — Generate the application key

```bash
php artisan key:generate
```

### Step 5 — Run migrations

```bash
php artisan migrate --force
```

### Step 6 — Fix permissions (Linux)

```bash
chmod -R 775 storage bootstrap/cache
```

## 4. Deploying the App in a Subdirectory (Important)

If the application lives at:

```
https://example.com/wro
```

then set:

```env
APP_URL="https://example.com/wro"
```

Laravel’s `url()` and `route()` helpers automatically prepend the subdirectory.

### NGINX Configuration

Add to your NGINX site:

```nginx
location /wro/ {
    alias /var/www/wro/public/;
    try_files $uri $uri/ /wro/index.php?$query_string;
}
```

## 5. Useful Laravel Commands

Clear caches:

```bash
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear
```